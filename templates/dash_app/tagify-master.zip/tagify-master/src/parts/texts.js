export default {
    empty      : "empty",
    exceed     : "number of tags exceeded",
    pattern    : "pattern mismatch",
    duplicate  : "already exists",
    notAllowed : "not allowed"
}